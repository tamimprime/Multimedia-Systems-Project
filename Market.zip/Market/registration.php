<?php



   

if(isset($_POST['Submit'])){



    $name   = $_POST['name'];
    
      $email = $_POST['email'];

    $username   = $_POST['username'];

    $password1 = $_POST['password1'];

    $password2  = $_POST['password2'];

    


    


   

   



    if($name == "" || $email  == "" || $username  == ""|| $password == "" || $password2 == ""){

        echo "Null Value Found";



    }

    else{

   



      }

     

   

}




?>