<?php



   

if(isset($_POST['submit'])){



    $name   = $_POST['name'];
    
      $email = $_POST['email'];

    $productId   = $_POST['productId'];

    $productName   = $_POST['productName'];

    $address  = $_POST['address'];

    $password  = $_POST['password'];


    


   

   



    if($name == "" || $email  == "" || $productId  == "" || $productName  == "" || $address  == "" || $password == ""){

        echo "Null Value Found";



    }

    else{

   



      }

     

   

}




?>