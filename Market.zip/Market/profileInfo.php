<?php



   

if(isset($_POST['submit'])){



    $name  = $_POST['name'];

    $email   = $_POST['email'];

    $address   = $_POST['address'];

    $password   = $_POST['password'];

   



    if($name == "" ||  $email   == "" ||  $address  == ""||   $password  == ""){

        echo "Null Value Found";



    }

    else{

   



      }

     

   

}




?>