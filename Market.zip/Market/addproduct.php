<?php



   

if(isset($_POST['submit'])){



    $id   = $_POST['id'];

    $productname   = $_POST['productname'];

    $quantity   = $_POST['quantity'];

   



    if($id == "" ||  $productname  == "" ||  $quantity  == ""){

        echo "Null Value Found";



    }

    else{

   



      }

     

   

}




?>