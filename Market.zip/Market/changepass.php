<?php


	if(isset($_POST['submit'])){

		
		$email2 = $_POST['email2'];
		
		

		
		if( $email2 == "" ){

            echo "Null Value Found";



        }

        else{

       



          }

         

       

    }




?>